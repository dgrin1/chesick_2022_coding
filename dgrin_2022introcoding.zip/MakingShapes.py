from vpython import *
#Web VPython 3.2
print("Hello,world!")
#sphere(position=vector(0,0,0),radius=5,color=color.blue)
box(position=vector(0,0,0),size=vector(0.5,0.3,0.2),color=color.red)
box(position=vector(2,0,0),size=vector(0.5,0.3,0.2),color=color.blue)
box(position=vector(0,2,0),size=vector(0.5,0.3,0.2),color=color.green)
